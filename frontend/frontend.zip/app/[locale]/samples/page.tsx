import SamplesPage from "@/src/components/pages/SamplesPage";

export default function Page() {
  return <SamplesPage />;
}
