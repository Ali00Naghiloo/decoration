export interface SampleTypes {
  id?: string;
  title: string;
  category: string;
}
